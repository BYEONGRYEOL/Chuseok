using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace Isometric.UI
{

    public class UI_KeyBinds : UI_Popup
    {
        // Start is called before the first frame update
        void Awake()
        {
            Init();
        }

        // Update is called once per frame
        void Update()
        {

        }
        public override void Init()
        {
            base.Init();
        }
        
    }

}