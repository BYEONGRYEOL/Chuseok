using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace Isometric
{

    public interface IMoveable
    {
        Sprite MyIcon
        {
            get;
        }
    }

}