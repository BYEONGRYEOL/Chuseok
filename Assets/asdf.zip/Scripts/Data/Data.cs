using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace Isometric.Data
{

    public class Data
    {
        public string hashValue;

        public Data()
        {
            hashValue = string.Empty;
        }
    }

}