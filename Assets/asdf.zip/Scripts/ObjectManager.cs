using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace Isometric.Utility
{

    public class ObjectManager : SingletonDontDestroyMonobehavior<ObjectManager>
    {
        
    }

}